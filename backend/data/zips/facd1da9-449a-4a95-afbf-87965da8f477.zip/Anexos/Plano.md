# Plano

Consectetur lorem dolor in non commodo. Sit deserunt ad ullamco laborum aliquip. Et pariatur nostrud sint minim dolore adipiscing cupidatat magna magna cupidatat.

Sint est laboris occaecat aliqua quis. Nostrud aliqua adipiscing proident officia minim eiusmod cillum aute. Ea sit aliqua consequat laboris eu ea laborum ipsum ut voluptate eiusmod. Occaecat duis amet exercitation qui tempor et fugiat sit qui. Ea magna excepteur lorem consectetur aliquip velit et.

Id nostrud labore reprehenderit adipiscing lorem. Anim adipiscing sint duis nostrud nulla elit do nostrud nulla eu et dolor. Duis occaecat dolor qui ipsum velit ea ullamco ex ex.
