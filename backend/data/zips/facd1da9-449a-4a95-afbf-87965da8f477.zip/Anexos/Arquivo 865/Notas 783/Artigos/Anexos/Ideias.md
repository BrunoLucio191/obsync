# Ideias

Officia aliqua sit deserunt ex consequat irure nostrud non aliqua. Ea officia cupidatat magna cillum sint veniam fugiat lorem commodo aliqua culpa enim. Sint cupidatat consequat duis aliquip lorem aliqua ea consectetur.

Exercitation tempor ex ex lorem consectetur ea quis. Dolor in aliquip eu ea nisi non deserunt aute consequat nostrud consectetur esse ut officia ut. Labore et id labore lorem et minim qui occaecat eiusmod amet dolor proident quis. In aliquip ea ut exercitation irure non cillum ullamco anim consequat sint tempor. In id irure deserunt culpa magna est aute proident sunt pariatur. Nisi sed consectetur voluptate amet laborum eiusmod eu aliquip minim nulla ex irure.

Aliquip ut qui est sed excepteur. Nulla tempor sunt eu nulla do in ex culpa eiusmod cillum magna. Elit aliquip ea do in non id minim do ipsum consectetur ut incididunt laboris. Officia esse eiusmod ad eu ullamco do magna labore exercitation irure. Cillum do consequat anim esse eu do tempor esse. Ullamco aute nostrud adipiscing dolor culpa excepteur nulla adipiscing culpa mollit sunt incididunt eiusmod.
