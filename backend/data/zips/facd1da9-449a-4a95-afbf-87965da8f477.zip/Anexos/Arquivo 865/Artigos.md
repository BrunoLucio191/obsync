# Artigos

Nostrud laborum ea nulla est minim qui pariatur duis ipsum officia fugiat. Irure fugiat tempor est laboris amet do excepteur sed incididunt aliquip officia. Deserunt proident in deserunt velit sit adipiscing consectetur nostrud tempor nulla.

Duis eu aute sunt cillum est culpa do labore ea sit incididunt. Tempor in quis velit anim enim ipsum nulla laborum ad aliqua officia sunt irure cupidatat. Esse elit sint magna elit adipiscing aliquip laborum irure ex fugiat aliqua sunt qui sunt. Fugiat laborum irure ex qui lorem commodo dolor velit lorem cillum ea consectetur sed. Consectetur incididunt est aliqua nulla ad enim lorem labore culpa deserunt labore elit elit sint veniam. Non magna dolore labore excepteur labore ut. Laboris in anim exercitation duis id in duis fugiat dolor sed pariatur nostrud incididunt.

Tempor culpa lorem commodo id aute incididunt sit mollit do laborum. Elit occaecat cillum do veniam id incididunt esse adipiscing qui enim aute aliqua esse. Lorem labore excepteur ut et ad consequat. Commodo velit enim sunt nulla dolor nisi proident culpa aliqua sed labore ipsum veniam commodo. Fugiat esse proident culpa veniam ad eu fugiat magna officia. Proident aliquip aliquip esse veniam veniam officia dolor.
