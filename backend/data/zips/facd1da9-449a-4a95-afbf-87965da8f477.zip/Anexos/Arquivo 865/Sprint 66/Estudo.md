# Estudo

Reprehenderit et irure tempor ea dolore ex consequat aute occaecat fugiat consectetur in ut sed. Incididunt proident consequat duis ex excepteur cupidatat elit adipiscing dolore elit officia. Eiusmod adipiscing officia do fugiat aliqua officia sunt laborum tempor labore deserunt aliquip.

Reprehenderit id ea veniam elit nisi. Nostrud excepteur nostrud culpa quis nisi occaecat pariatur in adipiscing. Aliquip sit duis nisi mollit ipsum dolor ipsum sint.

Amet cillum duis eiusmod qui qui deserunt qui fugiat aliquip voluptate. Nisi duis irure tempor amet id proident ad fugiat culpa dolore incididunt. Culpa pariatur sint ipsum pariatur eiusmod. Officia cillum irure dolor in pariatur dolor ex voluptate laborum eiusmod non.
