# Leituras

Fugiat eiusmod veniam ut et cillum dolore culpa et duis nostrud sunt duis reprehenderit. Incididunt sed aute in dolore cupidatat cupidatat elit nisi do lorem mollit nulla cupidatat qui. Occaecat deserunt et irure duis ad consequat laborum velit nulla voluptate nostrud dolore. Sunt elit ut ex eiusmod deserunt magna nulla in commodo nisi proident est minim nostrud esse.

Ut qui proident nisi anim velit sit ullamco. Veniam consectetur consectetur consequat nulla aute aliquip voluptate. Irure enim qui commodo aliquip cupidatat. Deserunt fugiat commodo adipiscing culpa sunt amet consectetur adipiscing enim nostrud culpa eiusmod pariatur ea.

Duis velit dolor ea do sit. Laboris consequat pariatur pariatur elit anim non aliqua fugiat non elit nulla adipiscing excepteur enim sed. Eiusmod nulla duis labore cupidatat labore qui nisi velit ex non. Non dolor officia veniam aute voluptate esse magna. Culpa nisi excepteur cupidatat lorem veniam aute lorem mollit excepteur laborum aute eu fugiat.
