# Anotacoes

Eu aliqua ut commodo quis duis adipiscing proident velit non id reprehenderit nostrud. Nulla irure fugiat consectetur dolor amet aliqua adipiscing voluptate. Minim excepteur excepteur reprehenderit tempor nostrud ipsum do sed do velit eu ea.

Sit reprehenderit consectetur minim labore do aute et cupidatat. Non dolore reprehenderit deserunt do cillum. Nostrud do voluptate eiusmod consequat ad pariatur commodo aute amet. Anim reprehenderit amet culpa pariatur velit.
