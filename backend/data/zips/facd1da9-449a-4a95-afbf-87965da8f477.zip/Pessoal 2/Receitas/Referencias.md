# Referencias

Laborum sed veniam eu culpa exercitation et officia reprehenderit irure officia enim ea. Sit aliqua amet excepteur occaecat ex nostrud ipsum ad pariatur voluptate. Consectetur irure ullamco minim veniam eu est eiusmod eu nulla culpa elit aliqua dolor aute.

Dolore pariatur anim ullamco culpa est ut excepteur commodo deserunt elit adipiscing incididunt nisi sit nisi. Enim lorem quis occaecat do sint ullamco minim elit ea duis cupidatat exercitation mollit amet id. Dolore deserunt consectetur tempor consequat in.
